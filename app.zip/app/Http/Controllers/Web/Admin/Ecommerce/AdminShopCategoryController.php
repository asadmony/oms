<?php

namespace App\Http\Controllers\Web\Admin\Ecommerce;

use App\Http\Controllers\Controller;

class AdminShopCategoryController extends Controller
{

}
