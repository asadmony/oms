<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ProductReplacement extends Model
{
    use HasFactory;

    public function items()
    {
        return $this->hasMany(ProductReplacement::class, 'product_replacement_id');
    }
}
