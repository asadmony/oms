<?php

namespace App\Services;

class EcommerceServices
{

    public function __construct()
    {

    }

}
