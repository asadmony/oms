<template>
    <div class="padding-around">
        <div class="card card-body  w3-animate-zoom">
            <div class="h1">Ecommerce Dashboard</div>
        </div>
    </div>
</template>