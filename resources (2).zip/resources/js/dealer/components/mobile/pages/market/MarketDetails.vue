<template>
    <div class="padding-top">
        <div class="card">
            <div class="card-header">
                Market: 
            </div>
            <div class="card-body">
                <table>
                    <tr>
                        <th>Name</th>
                        <th>:</th>
                        <td>awdwa</td>
                    </tr>
                    <tr>
                        <th>Name (bangla)</th>
                        <th>:</th>
                        <td>awdwa</td>
                    </tr>
                    <tr>
                        <th>Agent</th>
                        <th>:</th>
                        <td>awdwa</td>
                    </tr>
                    <tr>
                        <th>Upazila</th>
                        <th>:</th>
                        <td>awdwa</td>
                    </tr>
                    <tr>
                        <th>District</th>
                        <th>:</th>
                        <td>awdawd</td>
                    </tr>
                    <tr>
                        <th>Division</th>
                        <th>:</th>
                        <td>awdawd</td>
                    </tr>
                    <tr>
                        <th>Status</th>
                        <th>:</th>
                        <td>yes</td>
                    </tr>
                </table>
            </div>
        </div>
        <div class="card">
            <div class="card-header">
                Shop List
            </div>
            <div class="card-body">
                <shop-list></shop-list>
            </div>
        </div>
    </div>
</template>