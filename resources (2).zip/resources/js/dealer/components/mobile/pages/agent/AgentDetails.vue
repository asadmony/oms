<template>
    <div>
        agent details
    </div>
</template>