<template>
<agent-header-top>
    <h5 class="title-header ml-2">SR OMS </h5>
    <div class="header-right">
        <a href="#" class="btn-header"> <i class="fa fa-bell"></i> </a>
    </div>
</agent-header-top>
</template>
<script>
export default {
    created() {

    },
}
</script>
