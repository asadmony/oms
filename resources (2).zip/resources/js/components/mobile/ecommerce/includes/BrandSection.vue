<template>
    <div>
        
        <hr class="divider my-3">

        <h5 class="title-section">Brands</h5>

        <section class="padding-x">
            <ul class="row">
                <li class="col-6">
                    <a href="#" class="btn btn-light text-muted btn-block"> Adidas  </a>
                </li>
                <li class="col-6">
                    <a href="#" class="btn btn-light text-muted btn-block"> Puma </a>
                </li>
                <li class="col-6">
                    <a href="#" class="btn btn-light text-muted btn-block"> Reebok </a>
                </li>
                <li class="col-6">
                    <a href="#" class="btn btn-light text-muted btn-block"> Lacoste  </a>
                </li>
                <li class="col-6">
                    <a href="#" class="btn btn-light text-muted btn-block"> Brand name  </a>
                </li>
                <li class="col-6">
                    <a href="#" class="btn btn-light text-muted btn-block"> More </a>
                </li>
            </ul>
        </section>
    </div>
</template>