@extends('admin.layouts.adminMaster')
@section('title', 'Dhaka Metro News')

@push('css')
@endpush

@section('content')
  @include('admin.categories.parts.categoryAddNew')
@endsection


@push('js')
@endpush
