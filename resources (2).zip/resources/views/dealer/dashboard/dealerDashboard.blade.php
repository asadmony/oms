@extends('dealer.layouts.dealerMaster')

@push('css')
@endpush

@section('content')
  <section class="content">
  
  </section>
@endsection

@push('js')
@endpush