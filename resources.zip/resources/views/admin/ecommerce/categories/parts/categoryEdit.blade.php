<br>
<section class="content">
    <div class="card card-primary">
        <div class="card-header with-border">
            <h3 class="card-title">
                Manage Product Categories
            </h3>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-md-9">
                    <input id="search-input" class="search-input" />
                    <br>
                    <div id="SimpleJSTree">

                    </div>
                </div>
            </div>
        </div>
    </div>
</section>