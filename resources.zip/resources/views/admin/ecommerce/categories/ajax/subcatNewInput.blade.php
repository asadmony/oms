 <tbody>
	<tr>

		<td width="120">
			New Subcategory: 
		</td>

	<td>

		<input type="text" class="input-sm input-subcat-new" data-url="{{ route('admin.subcatAddNew', $cat) }}" placeholder="New Subcategory Name">
		<button class="btn btn-primary btn-sm btn-subcat-submit">Submit New Subcategory</button>
					
	</td>

	</tr>
</tbody>