@extends('agent.layouts.agentMaster')

@push('css')
@endpush

@section('content')
  <section class="content">
  
  </section>
@endsection


@push('js')

@auth

@else
 
 @endauth

@endpush

