<template>
<dealer-header-top>
    <h5 class="title-header ml-2">Dealer Ecommerce </h5>
    <div class="header-right">  
        <a href="#" class="btn-header"> <i class="fa fa-bell"></i> </a> 
    </div>
</dealer-header-top>
</template>