<template>
    <div>
        order details
    </div>
</template>