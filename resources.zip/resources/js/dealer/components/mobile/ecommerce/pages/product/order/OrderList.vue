<template>
    <div>
        <div class="padding-top">
            <div class="card">
                <div class="card-header">
                    Incoming Order List
                </div>
                <div class="card-body">
                    <ecom-incoming-order-list-item></ecom-incoming-order-list-item>
                    <ecom-incoming-order-list-item></ecom-incoming-order-list-item>
                    <ecom-incoming-order-list-item></ecom-incoming-order-list-item>
                    <ecom-incoming-order-list-item></ecom-incoming-order-list-item>
                </div>
            </div>
        </div>
    </div>
</template>