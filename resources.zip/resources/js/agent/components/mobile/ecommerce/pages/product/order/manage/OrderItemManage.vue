<template>
    <div>
        item manage {{ order }}
    </div>
</template>
<script>
export default {
    props: [
        'order'
    ],
    data() {
        return {
            
        }
    },
}
</script>