<template>
    <div>
        <header class="app-header bg-primary">
            <button class="btn-header" type="button" data-trigger="#sidebar_left"><i class="fa fa-bars"></i></button>
            <slot></slot>
        </header> <!-- section-header.// -->
    </div>
</template>

<script>
export default {

}
</script>
