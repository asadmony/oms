<template>
  <div>
      <form action="" class="padding-around">
            <div class="row">
                <div class="col-6"> 
                    <select class="custom-select form-control">
                        <option>Category</option>
                        <option>Clothes</option>
                        <option>Electronics</option>
                    </select>
                </div> <!-- col.// -->
                <div class="col-6">
                    <select class="custom-select form-control">
                        <option>Price cheap</option>
                        <option>Price high</option>
                        <option>Oldest</option>
                    </select>
                </div> <!-- col.// -->
            </div> <!-- row.// -->
        </form>
  </div>
</template>

<script>
export default {

}
</script>

<style>

</style>