<template>
    <section class="padding-around">
        <p class="text-center my-3">
            <a href=""  onclick="event.preventDefault();history.back()" class="btn btn-light w-100"> <i class="icon fa fa-arrow-left"></i>  <span class="text">Back</span> </a>
        </p>
    </section>
</template>